package com.example.attendanceapp;

public class Person {

    public Person(String NAME){
        isHere = false;
        name = NAME;
    }
    public boolean isHere;
    public String name;
}
